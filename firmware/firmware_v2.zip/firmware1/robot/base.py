#===============================================================================
#Archivo     : base.py
#Módulo      : robot
#Propósito   : Clase madre que define un robot móvil genérico.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#    - Fiorella Urbina (f.urbina@pucp.edu.pe)
#    - Rodrigo Carbajal (rodrigo.carbajals@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-06-20
#Versión     : 1.2.1
#
#Dependencias:
#    - robot.motor_driver (MotorWithPID)
#    - machine (Timer)
#
#Historial de cambios:
#    - v1.0   (2025-06-18) Diego Quiroz: Versión Inicial para control de robot
#    - v1.1   (2025-06-20) Diego Quiroz: Integración con PID
#    - v1.2   (2025-08-01) Fiorella Urbina: Integración con odometría por Euler
#    - v1.21  (2025-08-04) Rodrigo Carbajal: Integración con estimación de pose
#    - v1.22  (2025-06-26) Fiorella Urbina: Corrección de mezcla de unidades.
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from robot.motor_driver import MotorWithPID
from machine import Timer
from utils.pose_estimator import PoseEstimator, Pose
import math

class MobileRobot:
    def __init__(self, motor_configs):
        '''
        Inicializa el robot móvil con múltiples motores controlados por PID.
        
        Parámetros:
          motor_configs: Lista de diccionarios con los parámetros de configuración
                         de cada motor (pines de control y encoder)
                         
        Salida:
          self.motors: Lista de objetos MotorWithPID
        '''
        self.motors = [MotorWithPID(**cfg) for cfg in motor_configs]
        self._custom_jacobian_fn = None
        self._custom_estimation_fn = None
        self._control_timer = None
        # Odometria
        self._odometry_timer = None
        self.pose = Pose(x=0,y=0,theta=0) # Posición y orientación actual del robot 
        self.pose_prev = Pose(x=0,y=0,theta=0) # Posición y orientación previa del robot
        self.pose_estimator = PoseEstimator(self.pose)

    #=========================================================
    # Esta función permite mover el robot en una dirección y
    # rotación deseada utilizando el modelo cinemático (jacobiano).
    # Calcula la velocidad individual de cada rueda y la asigna
    # a su respectivo motor.
    #=========================================================
    def move(self, vx, vy, omega):
        '''
        Calcula y aplica velocidades individuales de ruedas a partir de
        velocidades del chasis.

        Parámetros:
          vx: Velocidad lineal en eje X [m/s]
          vy: Velocidad lineal en eje Y [m/s]
          omega: Velocidad angular del chasis [rad/s]
        '''
#         if abs(vx)/vx != self.last_dir_x:
#             self.last_dir_x = not self.last_dir_x
#             self.stop()
#         if abs(vy)/vy != self.last_dir_y:
#             self.last_dir_y = not self.last_dir_y
#             self.stop()
        
        speeds = self._compute_wheel_speeds(vx, vy, omega)
        for motor, speed in zip(self.motors, speeds):
            motor.set_speed(speed, units="rad_s")


    #=========================================================
    # Esta función detiene el movimiento del robot
    #=========================================================
    def stop(self):
        '''
        Detiene el robot móvil, estableciendo todas las velocidades a cero.
        '''
        if (self._control_timer):
            self._control_timer.deinit()
        for motor in self.motors:
            motor.stop()
    
    #=========================================================
    # Esta función calcula las velocidades de cada rueda a partir
    # de la velocidad lineal y angular del chasis. Requiere
    # implementación específica dependiendo del tipo de robot
    # (ej. diferencial, mecanum).
    #=========================================================
    def _compute_wheel_speeds(self, vx, vy, omega):
        '''
        Método abstracto para calcular velocidades individuales de rueda
        a partir del modelo cinemático del robot.

        Parámetros:
          vx: Velocidad lineal en X
          vy: Velocidad lineal en Y
          omega: Velocidad angular

        Salida:
          Lista con velocidades por rueda
        '''
        raise NotImplementedError

    #=========================================================
    #=========================================================
    def get_motors_speed(self,units="rpm"):
        '''
        Parámetros:
            units: "rpm" para revoluciones por minuto, "rad_s" para radianes por segundo
        Salida: Lista con las velocidades actuales de cada motor en unidades especificadas
        '''
        motors_speed = [(motor.get_speed(units)) for motor in self.motors] 
        return motors_speed
    
    #=========================================================
    # Retorna el jacobiano actual, usando el personalizado si
    # ha sido definido. De lo contrario, retorna el jacobiano
    # por defecto (debe implementarse en utils/jacobians y ser
    # importado por cada configuración de vehículo).
    #=========================================================
    def _jacobian(self):
        '''
        Obtiene la matriz jacobiana que relaciona velocidades del chasis con
        velocidades de ruedas.

        Salida:
          Jacobiano actual (matriz 2D)
        '''
        if self._custom_jacobian_fn:
            return self._custom_jacobian_fn()
        return self.default_jacobian()
        
    #=========================================================
    # Esta función permite establecer un jacobiano personalizado.
    # Empleado por los alumnos para probar y validar sus respuestas.
    #=========================================================
    def set_custom_jacobian(self, func):
        '''
        Define una función externa para calcular el jacobiano personalizado.

        Parámetros:
          func: Función sin argumentos que retorna la matriz jacobiana 2D (lista de listas o tuplas)
        '''
        self._custom_jacobian_fn = func

    #=========================================================
    # Define la matriz jacobiana por defecto. Esta función debe
    # ser implementada en una subclase específica del robot móvil.
    #=========================================================
    def default_jacobian(self):
        '''
        Método abstracto que debe ser implementado en clases hijas.
        
        Salida:
          Matriz jacobiana por defecto del robot
        '''
        raise NotImplementedError("Debe definir default_jacobian() en la subclase del robot")
    #=========================================================
    # Funciones de Control
    #=========================================================
    def enable_auto_update(self, interval=10):
        self._control_timer = Timer()
        self._control_timer.init(
            period=interval,
            mode=Timer.PERIODIC,
            callback=lambda t: self._update_motors()
        )
    def disable_auto_update(self):
        self._control_timer.deinit()
        
    def _update_motors(self):
        #print('updating')
        for motor in self.motors:
            motor.update()
            
    def set_control_mode(self, closed_loop=False):
        for motor in self.motors:
            motor.enable_close_loop_control(closed_loop)
            
    def set_pid_constants(self, motor_index, kp, ki=None, kd=None):
        if 0 <= motor_index < len(self.motors):
            self.motors[motor_index].tune_pid(kp, ki, kd)
            
    #=========================================================
    # Actualiza la odometría del robot utilizando datos de
    # encoders y/o IMU. La implementación específica depende
    # del tipo de sensores y modelo cinemático
    #=========================================================
    def update_odometry(self, interval=10, encoders=False, imu=False):
        '''
        Método abstracto para estimar la posición y orientación del robot.
        Deberá combinar encoders e IMU si están disponibles.
        '''
        raise NotImplementedError
        
    #=========================================================
    # Esta función permite estimar la pose a partir de la pose previa y la actual.
    # Empleado por los alumnos para probar y validar sus respuestas.
    #=========================================================
    def set_custom_estimation(self, func):
        '''
        Define una función externa para estimar la pose a partir de la 
        pose previa y la actual.

        Parámetros:
          func: Función con argumentos pose y pose_prev que retorna la pose estimada (actual)
        '''
        self._custom_estimation_fn = func
    
    def enable_auto_update_odometry(self, interval=10, encoders=True, imu=False, enable=True):
        '''
        Habilita la actualización periódica de la odometría del robot.

        Parámetros:
          interval: Intervalo en milisegundos para actualizar la odometría
        '''
        if enable:
            self._odometry_timer = Timer()
            self._odometry_timer.init(
                period=interval,
                mode=Timer.PERIODIC,
                callback=lambda t: self.update_odometry(interval, encoders, imu)
            )
        else:
            self._odometry_timer.deinit()
