#===============================================================================
#Archivo     : AnalogUltrasonicSensor.py
#Módulo      : sensors
#Propósito   : Obtener la distancia de un sensor ultrasonico analógico. Se utiliza
#              para detectar obstáculos en sistemas robóticos.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-06-30
#Versión     : 1.0
#
#Dependencias:
#    - machine (ADC)
#
#Historial de cambios:
#    - v1.0 (2025-06-14) Diego Quiroz: Encapsulamiento en clase inicial.
#                                      Lectura de datos con unidades distintas.
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from machine import ADC

class AnalogUltrasonicSensor:
    """
    Clase para sensores ultrasónicos con salida analógica conectados a un pin ADC.
    """
    def __init__(self, adc_pin, vref=3.3, max_distance=1024):
        '''
        Inicializa un sensor ultrasonido con salida analógica

        Parámetros:
          adc_pin: número de pin ADC (ej. 26, 27, etc.)
          vref: voltaje de referencia del ADC (3.3V por defecto)
          max_distance: distancia máxima del sensor [mm]
        '''
        self.adc = ADC(adc_pin)
        self.vref = vref
        self.max_distance = max_distance
        
    def read_voltage(self):
        '''
        obtiene el valor de voltaje analógico retornado por el sensor
        '''
        raw = self.adc.read_u16()
        return (raw / 65535) * self.vref
    
    def read_distance(self, unit='mm'):
        '''
        Calcula la distancia basada en el voltaje leído.

        Parámetros:
            unit: 'mm', 'cm' o 'in' (pulgadas)

        Salida:
            distancia: Distancia en la unidad especificada
        '''
        distance_mm = (self.read_voltage() / self.vref) * self.max_distance
        
        if unit == 'mm':
            return distance_mm
        elif unit == 'cm':
            return distance_mm / 10
        elif unit == 'in':
            return distance_mm / 25.4
        else:
            raise ValueError("Unidad inválida: usar 'mm', 'cm' o 'in'")