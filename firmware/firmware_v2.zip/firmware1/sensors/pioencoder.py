# encoder_rp2.py Uses the PIO for rapid response on RP2 chips (Pico)

# Copyright (c) 2022 Peter Hinch
# Released under the MIT License (MIT) - see LICENSE file

# PIO and SM code written by Sandor Attila Gerendi (@sanyi)
# https://github.com/micropython/micropython/pull/6894

from machine import Pin
from array import array
import rp2
import utime

# Closure enables Viper to retain state. Currently (V1.17) nonlocal doesn't
# work: https://github.com/micropython/micropython/issues/8086
# so using arrays.
def make_isr(pos):
    old_x = array("i", (0,))

    @micropython.viper
    def isr(sm):
        i = ptr32(pos)
        p = ptr32(old_x)
        while sm.rx_fifo():
            v: int = int(sm.get()) & 3
            x: int = v & 1
            y: int = v >> 1
            s: int = 1 if (x ^ y) else -1
            i[0] = i[0] + (s if (x ^ p[0]) else (0 - s))
            p[0] = x

    return isr


# Args:
# StateMachine no. (0-7): each instance must have a different sm_no.
# An initialised input Pin: this and the next pin are the encoder interface.
# Pins must have pullups (internal or, preferably, low value 1KΩ to 3.3V).
class Encoder:
    def __init__(self, sm_no, base_pin, scale=1, inverted=False):
        self.inverted = inverted
        self.scale = scale
        self._pos = array("i", (0,))  # [pos]
        
        self.last_time = utime.ticks_ms()
        self.last_count = 0
        
        self.sm = rp2.StateMachine(sm_no, self.pio_quadrature, in_base=base_pin)
        self.sm.irq(make_isr(self._pos))  # Instantiate the closure
        self.sm.exec("set(y, 99)")  # Initialise y: guarantee different to the input
        self.sm.active(1)

    @rp2.asm_pio()
    def pio_quadrature(in_init=rp2.PIO.IN_LOW):
        wrap_target()
        label("again")
        in_(pins, 2)
        mov(x, isr)
        jmp(x_not_y, "push_data")
        mov(isr, null)
        jmp("again")
        label("push_data")
        push()
        irq(block, rel(0))
        mov(y, x)
        wrap()

    def position(self, value=None):
        if value is not None:
            self._pos[0] = round(value / self.scale)
        return self._pos[0] * self.scale

    def value(self, value=None):
        if value is not None:
            self._pos[0] = value
        return self._pos[0]
    
    #---------------------------------------------------------
    # Added by Diego Quiroz
    #---------------------------------------------------------
    #=========================================================
    # Esta función permite obtener de la cuenta actual del encoder
    # Mantiene compatibilidad con versión previa (sin PIO)
    #=========================================================
    def get_count(self):
        return self.value()
    
    #=========================================================
    # Esta función permite obtener la velocidad de giro actual
    # del encoder. Considera los pulsos que se han detectado
    # en conjunto con el tiempo transcurrido para determinar
    # velocidad usando la formula pulsos/tiempo
    #=========================================================
    def get_speed(self, ppr=2750):
        '''
        Retorna la velocidad actual de giro del motor en PRM
        
        Parámetros:
          ppr: pulsos por revolución
          
        Salida:
          rpm: velocidad actual de giro en RPM
        '''
        now = utime.ticks_ms()
        dt = utime.ticks_diff(now, self.last_time) / 1000
        if dt == 0:
            return 0
        
        delta = self._pos[0] - self.last_count
        revolutions = delta / ppr
        rpm = revolutions * 60 / dt
        
        self.last_count = self._pos[0]
        self.last_time = now
        
        if self.inverted:
            rpm = -rpm
        return rpm
