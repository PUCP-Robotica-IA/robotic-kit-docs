#===============================================================================
#Archivo     : encoder.py
#Módulo      : sensors
#Propósito   : Clase que define el comportamiento y lectura de un encoder de cuadratura.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-06-18
#Versión     : 1.0
#
#Dependencias:
#    - machine (PIN)
#
#Historial de cambios:
#    - v1.0   (2025-06-18) Diego Quiroz: Versión Inicial para lectura de encoders
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from machine import Pin
import utime

class Encoder:
    def __init__(self, pin_a, pin_b):
        # Configura Pines de un Encoder
        self.a = Pin(pin_a, Pin.IN)
        self.b = Pin(pin_b, Pin.IN)
        
        self.state = (self.a.value() << 1) | self.b.value()
        self.count = 0
        self.last_time = utime.ticks_ms()
        self.last_count = 0
        # Configura rutinas de interrupcion para contar pulsos de ambos canales
        self.a.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=self.callback)
        self.b.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=self.callback)
        
    #=========================================================
    # Esta función se ejecuta al detectar un pulso en los pines
    # del encoder. Determina la dirección de giro y aumenta o
    # reduce la cuenta del encoder según corresponda
    #=========================================================
    def callback(self, pin):
        '''
        Actualiza la cuenta actual del encoder de cuadratura.
        
        Parámetros:
          pin: pin que genera la interrupción
          
        Salida:
          self.count: Actualiza la cuenta actual
        '''
        #El estado del sensor representa el nivel lógico del encoder
        new_state = (self.a.value() << 1) | self.b.value()
        transition = (self.state << 2) | new_state
        
        #Decodifica transiciones validas para encoder de cuadratura
        if transition in (0b0001, 0b0111, 0b1110, 0b1000):
            self.count += 1  # Horario
        elif transition in (0b0010, 0b0100, 0b1101, 0b1011):
            self.count -= 1  # Anti-horario
        #Look up table
        #lookup = {
        #    0b0001: 1, 0b0111: 1,
        #    0b1110: 1, 0b1000: 1,
        #    0b0010: -1,0b0100: -1,
        #    0b1101: -1, 0b1011: -1
        #}
        #self.count += lookup.get(transition, 0)
            
        self.state = new_state
            
    #=========================================================
    # Esta función permite obtener de la cuenta actual del encoder
    #=========================================================
    def get_count(self):
        return self.count
    
    #=========================================================
    # Esta función permite obtener la velocidad de giro actual
    # del encoder. Considera los pulsos que se han detectado
    # en conjunto con el tiempo transcurrido para determinar
    # velocidad usando la formula pulsos/tiempo
    #=========================================================
    def get_speed(self, ppr= 2750):
        '''
        Retorna la velocidad actual de giro del motor en PRM
        
        Parámetros:
          ppr: pulsos por revolución
          
        Salida:
          rpm: velocidad actual de giro en RPM
        '''
        now = utime.ticks_ms()
        dt = utime.ticks_diff(now, self.last_time) / 1000
        if dt == 0:
            return 0
        
        delta = self.count - self.last_count
        revolutions = delta / ppr
        rpm = revolutions * 60 / dt
        
        self.last_count = self.count
        self.last_time = now
        
        return rpm
