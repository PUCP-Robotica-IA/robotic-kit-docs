#===============================================================================
#Archivo     : ultrasonic_array.py
#Módulo      : sensors
#Propósito   : Clase controlador de sensores ultrasonido. Genera un arreglo de
#              sensores, los cuales pueden ser procesados y analizados en conjunto
#              o de forma independiente.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-01
#Versión     : 0.5
#
#Dependencias:
#    - sensors.ultrasound_sensor (AnalogUltrasonicSensor)
#
#Historial de cambios:
#    - v0.5 (2025-07-01) Diego Quiroz: Versión Inicial para seteo y lectura
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from sensors.ultrasound_sensor import AnalogUltrasonicSensor

class UltrasonicArray:
    '''
    Clase que representa un conjunto de sensores ultrasónicos analógicos
    montados en el robot. Permite leer múltiples sensores con nombres lógicos 
    como "front", "left", "right", etc.

    Parámetros de inicialización:
      sensor_config: Diccionario con las configuraciones de los sensores.
                     Cada entrada puede ser:
                        - Un entero (forma corta): representa el pin ADC.
                          Ej: {"front": 26}
                        - Un diccionario con parámetros para AnalogUltrasonicSensor.
                          Ej: {"front": {"adc_pin": 26, vref=3.3, max_distance=1024}}

    Atributos:
      self.sensors: Diccionario de sensores inicializados.
    '''
    def __init__(self, sensor_config):
        self.sensors = {}
        for name, cfg in sensor_config.items():
            if isinstance(cfg, int):
                # forma corta: "left": 26
                self.sensors[name] = AnalogUltrasonicSensor(adc_pin=cfg)
            elif isinstance(cfg, dict):
                # Se usa un diccionaario con las claves correctas, se usa **cfg
                self.sensors[name] = AnalogUltrasonicSensor(**cfg)
            else:
                raise TypeError(f"Entrada no válida para sensor '{name}': {cfg}")
    
    #=========================================================
    # Esta función retorna un diccionario con la lectura de 
    # todos los sensores configurados.
    #=========================================================
    def read_all(self, unit='mm'):
        '''
        Lee todos los sensores ultrasónicos del arreglo.
        
        Parámetros:
          unit: Unidad de salida ('mm' por defecto)

        Salida:
          Diccionario con las lecturas por nombre lógico.
          Ej: {"front": 23.4, "left": 18.9, ...}
        '''
        return {name: sensor.read_distance(unit) for name, sensor in self.sensors.items()}
    
    #=========================================================
    # Esta función lee la distancia desde un sensor específico.
    # Permite seleccionar la unidad de salida.
    #=========================================================
    def read(self, name, unit='mm'):
        '''
        Lee la distancia medida por un sensor individual.

        Parámetros:
          name: Identificador del sensor (ej. "front").
          unit: Unidad de salida ('mm' por defecto)

        Salida:
          Distancia medida por el sensor especificado.
        '''
        if name in self.sensors:
            return self.sensors[name].read_distance(unit)
        raise ValueError(f"Sensor '{name}' no existe.")