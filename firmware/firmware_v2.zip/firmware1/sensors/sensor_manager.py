#===============================================================================
#Archivo     : sensor_manager.py
#Módulo      : sensor
#Propósito   : Clase que gestiona lectura de sensores para sistemas robóticos.
#-------------------------------------------------------------------------------
#Autores     :
#    - Gruzver Phocco (gruzver.phocco@pucp.edu.pe)
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-13
#Versión     : 1.0
#
#Dependencias:
#    - robot.base (MobileRobot)
#    - utils.jacobians (mecanum_jacobian)
#    - sensor.ultrasonic_array (UltrasonicArray)
#
#Historial de cambios:
#    - v1.0   (2025-07-13) Diego Quiroz: Versión Inicial para gestion de sensores.
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from sensors.ultrasonic_array import UltrasonicArray
from sensors.imu import IMUSensor

class SensorManager:
    def __init__(self, sensor_config):
        '''
        Inicializa los sensores disponibles según el diccionario de configuración.

        Ejemplo de config:
          {
              "ultrasonic": {"front": 26, "left": 27, "right": 28},
              "imu": {"i2c_id": 0, "sda": 16, "scl": 17}
          }
        '''
        if sensor_config and "ultrasonic" in sensor_config:
            self.ultrasonic = UltrasonicArray(sensor_config["ultrasonic"])
        else:
            self.ultrasonic = None
            
        if sensor_config and "imu" in sensor_config:
            self.imu = IMUSensor(sensor_config["imu"])
        else:
            self.imu = None

    #=========================================================
    # Estas funciones corresponden al sensor imu
    #=========================================================
    def read_imu_theta(self, in_radian=False):
        if self.imu:
            return self.imu.read_theta(in_radian)
        return None
    
    def read_imu_values(self):
        if self.imu:
            return self.imu.read()
        return None
    
    #=========================================================
    # Estas funciones corresponden a los sensores ultrasónicos
    #=========================================================
    def read_ultrasonic_value(self, id_ultr, unit='mm'):
        '''
        Retorna la distancia leída por un sensor ultrasónico específico.

        Parámetros:
          sensor_id: Identificador lógico del sensor (ej. "front", "left")
          unit     : Unidad de medida ('mm' o 'cm')

        Salida:
          Distancia en la unidad especificada
        '''
        if self.ultrasonic:
            return self.ultrasonic.read(id_ultr, unit)
        return none
    
    def read_ultrasonic_all(self, unit='mm'):
        '''
        Retorna la lectura de todos los sensores ultrasónicos disponibles.

        Parámetros:
          unit: Unidad de medida ('mm' o 'cm')

        Salida:
          Diccionario con las distancias medidas por sensor.
          Ej: {"front": 20.4, "left": 18.0, "right": 22.3}
        '''
        if self.ultrasonic:
            return self.ultrasonic.read_all(unit)
        return None