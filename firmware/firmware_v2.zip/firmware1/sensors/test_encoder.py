from machine import Pin
import utime

class Encoder:
    def __init__(self, pin_a, encoder_inverted=False):
        """
        Inicializa el encoder para Raspberry Pi Pico
        Args:
            pin_a: Pin para la señal A del encoder
            pin_b: Pin para la señal B del encoder (opcional para detección de dirección)
        """
        self.pin_a = Pin(pin_a, Pin.IN, Pin.PULL_UP)
        self.last_time = utime.ticks_ms()
        self.count = 0
        # Configurar interrupción - solo contar pulsos
        self.pin_a.irq(trigger=Pin.IRQ_RISING|Pin.IRQ_FALLING, handler=self._encoder_callback)
        self.direction = 1
    
    def _encoder_callback(self, pin):
        self.count += 1
    def get_count(self):
        return self.count
    def set_direction(self, direction):
        if direction:
            self.direction = direction
        else:
            self.direction = -1
    
    def get_speed(self, ppr = 640):
        '''
        Retorna la velocidad actual de giro del motor en PRM
        
        Parámetros:
          ppr: pulsos por revolución
          
        Salida:
          rpm: velocidad actual de giro en RPM
        '''
        now = utime.ticks_ms()
        dt = utime.ticks_diff(now, self.last_time) / 1000
 
        if dt == 0:
            return 0
        revolutions = self.count / ppr 
        rpm = revolutions * 60 / dt
        self.count = 0
        self.last_time = now
        
        return rpm * self.direction
    
        