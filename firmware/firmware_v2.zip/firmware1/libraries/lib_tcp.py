
import network, utime
from machine import Pin, Timer

def blink_led(times, interval=200, end_with_led_on=False):
    led = Pin("LED", Pin.OUT)
    for _ in range(times):
        led.on()
        utime.sleep_ms(interval)
        led.off()
        utime.sleep_ms(interval)
    if end_with_led_on:
        led.on()


class wlanConnection:
    def __init__(self, ssid=None, password=None):
        self.wlan = network.WLAN(network.STA_IF)
        self.ssid = ssid
        self.password = password
        self.ip_addr = None
    
    def set_config(self, config):
        self.ssid = config['ssid']
        self.password = config['password']

    def connect(self,timeout=10): #Timeout por defecto está bien, o más largo?
        '''Conectar a una red y esperar hasta que se establezca la conexión o se agote el tiempo'''
        print(f"Conectando a {self.ssid}...")
        self.wlan.active(True)
        self.wlan.connect(self.ssid, self.password)
        print("Conexión exitosa.")
        
        t = 0
        while not self.wlan.isconnected and t < timeout:
            print(f"Esperando conexión... {t}/{timeout} segundos")
            utime.sleep(1)
            t += 1
        if not self.wlan.isconnected:
            raise TimeoutError("No se pudo conectar a la red Wi-Fi en el tiempo especificado")
        
        self.ip_addr = self.wlan.ifconfig()[0]
        print(f"Conectado a {self.ssid} con IP {self.ip_addr}")
        blink_led(2,500)

 

import socket
class SimpleTCPClient:
    def __init__(self, host='0.0.0.0', port=6112):
        self.host = host
        self.port = port
        self.sock = None
    
    def set_config(self,config):
        self.host = config['host']
        self.port = config['port']

    def connect(self):       
        
        #while True:
        try:
            '''Conexion a Servidor TCP'''
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            #self.sock.settimeout(3)
            #print('Intentando conectar a TCP server')
            self.sock.connect((self.host, self.port))
            blink_led(1,200,True)
            return
        except Exception as e:
            print(f'{e} \n No se pudo conectar, reintentando...')
            blink_led(1,600)
            self.sock.close()
            self.sock = None
            utime.sleep(1)

    def send(self, data):
        '''Enviar datos al servidor TCP'''
        if self.sock is None:
            raise Exception("Socket no conectado")
        self.sock.sendall(data)
    
    def send_string(self, data):
        '''Enviar una cadena de texto al servidor TCP'''
        if isinstance(data, str):
           self.send(data.encode('utf-8'))


    def receive(self, buffer_size=1024):
        '''Recibir datos del servidor TCP'''
        if self.sock is None:
            raise Exception("Socket is not connected.")
        return self.sock.recv(buffer_size)

    def close(self):
        '''Cerrar la conexión TCP'''
        if self.sock:
            self.sock.close()
            self.sock = None