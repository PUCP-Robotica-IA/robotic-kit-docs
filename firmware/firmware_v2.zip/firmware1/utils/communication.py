#===============================================================================
# Archivo     : communication.py
# Módulo      : utils
# Propósito   : Clase que gestiona la comunicación remota (MQTT) para telemetría
#               y teleoperación en sistemas robóticos móviles.
#-------------------------------------------------------------------------------
# Autores     :
#    - Gruzver Phocco (gruzver.phocco@pucp.edu.pe)
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
# Carrera     : Ingeniería Mecatrónica
# Curso       : 1MTR53 - Robótica e Inteligencia Artificial
# Institución : PUCP - Facultad de Ciencias e Ingeniería
#
# Fecha       : 2025-07-13
# Versión     : 1.0
#
# Dependencias:
#    - utils.mqtt (MQTT)
#
# Historial de cambios:
#    - v1.0   (2025-07-13) Diego Quiroz: Versión inicial de clase de comunicación
#
# Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================

from utils.mqtt import MQTT

class CommunicationManager:
    '''
    Clase que encapsula la comunicación remota del robot mediante protocolo MQTT.
    Permite publicar y suscribirse a mensajes utilizando una interfaz simplificada.

    Esta clase facilita la integración de la telemetría (envío de datos de sensores)
    y la teleoperación (recepción de comandos remotos) en robots móviles educativos.

    Parámetros:
      comm_config: Diccionario de configuración. Debe incluir clave "mqtt".
    '''
    def __init__(self, communication_config):
        '''
        Inicializa el módulo de comunicación con los parámetros definidos.

        Parámetros:
          comm_config: diccionario con la configuración del sistema de comunicación.
                       Ejemplo:
                         {
                             "mqtt": {"ssid": "redpucp", "password": "C9AA28BA93", "mqtt_server": "broker.hivemq.com"}
                         }
        '''
        if communication_config and "MQTT" in communication_config:
            self._mqtt = MQTT(communication_config["MQTT"])
        else:
            self._mqtt = None

    #===========================================================================
    # Publica un mensaje en un tópico específico.
    #===========================================================================
    def publish(self, topic, msg):
        '''
        Publica un mensaje MQTT.

        Parámetros:
          msg  : Mensaje a enviar (str)
          topic: Tópico en el que se publica el mensaje (str)
        '''
        if self._mqtt:
            self._mqtt.publish_mqtt(topic, msg)

    #===========================================================================
    # Se suscribe a un tópico y retorna el último mensaje recibido.
    #===========================================================================
    def subscribe(self, topic):
        '''
        Consulta el mensaje más reciente en un tópico MQTT.

        Parámetros:
          topic: Tópico a consultar (str)

        Salida:
          Mensaje recibido (str o None si no hay nuevos mensajes)
        '''
        if self._mqtt:
            return self._mqtt.subscribe_mqtt(topic)
        return None
 
    def add_callback(self, topic, handler):
        self._mqtt.add_callback(topic, handler)
        
    def check_incoming(self):
        self._mqtt.check_incoming()
