import math

def control_velocity_to_position(pose_act, x_goal, y_goal, gain = 1.0):
    """
    Controlador proporcional para alcanzar una posición (x_goal, y_goal).
    Devuelve velocidades en el marco global.

    Parámetros:
      pose_act : pose actual (x, y, theta)
      x_goal, y_goal : coordenadas objetivo
      gain : ganancia proporcional (negativa para atracción)

    Retorna:
      [vx, vy, 0] : Velocidades deseadas
    """
    vx = gain * (x_goal - pose_act.x)
    vy = gain * (y_goal - pose_act.y)
    return [vx, vy, 0]

def control_velocity_to_orientation(pose, thetaGoal, gain = 1.5):
    """
    Controlador proporcional para alinear la orientación del robot.

    Parámetros:
      pose : objeto con atributos x, y, theta
      theta_goal : orientación objetivo [rad]
      gain : ganancia proporcional

    Retorna:
      [0, 0, vw] : Solo velocidad angular
    """
    orientation_error = thetaGoal - pose.theta
    
    # Normaliza a rango [-2pi, 2pi]
    if orientation_error >= 2*math.pi:
        orientation_error -= 2*math.pi
    elif orientation_error <= -2*math.pi:
        orientation_error += 2*math.pi
    
    vw = gain * orientation_error
    
    if (abs(vw) > math.pi) :
        vw = (vw/abs(vw)) * math.pi
    if abs(orientation_error) < 0.2:
        vw = (orientation_error/abs(orientation_error))*math.pi/6
        
    return [0, 0, vw]

def calculate_direction_goal(pose, goal):
    """
    Calcula la dirección (ángulo) hacia el objetivo en el marco global desde la pose actual.

    Parámetros:
      pose : objeto con atributos x, y, theta
      goal : objeto con atributos x, y, theta (coordenadas y orientación objetivo)

    Retorna:
      direction_goal : ángulo de dirección hacia el objetivo en radianes
    """
    
    delta_x = goal.x - pose.x
    delta_y = goal.y - pose.y
    
    direction_goal = math.atan2(delta_y, delta_x)
    
    if (direction_goal >= 2*math.pi):
        
        direction_goal -= 2*math.pi
        
    elif (direction_goal <= -2*math.pi):
        
        direction_goal += 2*math.pi
    
    return direction_goal

def calculate_mov3(pose, goal, linealGain, angularGain):
    vx = linealGain * (goal.x - pose.x)
    vy = linealGain * (goal.y - pose.y)
    orientation_error = goal.theta - pose.theta
    
    # Normaliza a rango [-2pi, 2pi]
    if orientation_error >= 2*math.pi:
        orientation_error -= 2*math.pi
    elif orientation_error <= -2*math.pi:
        orientation_error += 2*math.pi
    
    vw = angularGain * orientation_error
    
    if (abs(vw) > math.pi) :
        vw = (vw/abs(vw)) * math.pi
    if abs(orientation_error) < 0.2:
        vw = (orientation_error/abs(orientation_error))*math.pi/6
    
    return [vx, vy, vw]
    
    
