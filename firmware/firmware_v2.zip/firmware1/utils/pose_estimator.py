#===============================================================================
#Archivo     : pose_estimator.py
#Módulo      : utils
#Propósito   : Clase para estimar la pose del robot usando encoders y cinemática.
#-------------------------------------------------------------------------------
#Autores     :
#    - Rodrigo Carbajal (rodrigo.carbajals@pucp.edu.pe)
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#    - Fiorella Urbina (f.urbina@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-08-14
#Versión     : 1.1
#
#Dependencias:
#    - math
#    - ucollections.namedtuple
#
#Historial de cambios:
#    - v1.0   (2025-06-18) Diego Quiroz: Versión Inicial encapsulando código desarrollado
#    - v1.1   (2025-08-14) Fiorella Urbina: Agrega opción de métodos personalizados
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
import math
import utime
from ucollections import namedtuple
#import inspect
from utils.transforms import robot_to_global_frame
from utils.estimations import euler, bilineal

Pose = namedtuple("pose",("x","y","theta"))
Vel = namedtuple("vel",("vx","vy","omega"))

class PoseEstimator:
    def __init__(self, pose, method='Euler'):
        '''
        Inicializa el estimador de pose con una pose inicial y un método de estimación.
        Parámetros:
            pose: Tupla con la pose inicial (x, y, theta)
            method: Método de estimación predefinido a utilizar ('Euler' o 'Bilineal')
        '''
        self.pose = pose
        self.pose_prev = Pose(0,0,0)
        self.pose_prev2 = Pose(0,0,0)
        self.vel_prev = Vel(0,0,0)
        self.method = method
        self.custom_method = None
        self.previous_time = None
    
    def _get_elapsed_time(self):
        now = utime.ticks_ms()
        dt = utime.ticks_diff(now, self.previous_time)
        self.previous_time = now
        return dt

    def set_custom_method(self, func):
        '''
        Permite registrar funciones personalizadas, que reciben:
        (pose, pose_prev, vel, vel_prev, dt)

        Parámetros:
            func: Función personalizada que recibe la pose actual, pose previa,
                    velocidad actual, velocidad previa y el tiempo transcurrido.
        '''
        #n_args = len(inspect.signature(func).parameters)

        #if n_args != 5:
        #    raise ValueError("La función personalizada debe recibir 5 argumentos: " \
        #    "pose, pose_prev, vel, vel_prev, dt")
        
        self.method = "Custom"
        
        # Función intermedia para pasar los atributos self a la función personalizada
        def _method(vel, dt):
            return func(self.pose,self.pose_prev, vel, self.vel_prev, dt)

        self.custom_method = _method

    def __call__(self, theta,  robot_velocities, scale = 1):
        '''
        Actualiza la pose del robot en función de las velocidades del robot y el método seleccionado
        o un método personalizado si se ha definido.
        Parámetros:
            robot_velocities: Tupla con las velocidades del robot en su marco local (vx, vy, omega)
        Salida:
            Una tupla con la nueva pose del robot Pose(x, y, theta)
        '''
        if not self.previous_time:
            self.previous_time = utime.ticks_ms()
            return self.pose
        

        dt = self._get_elapsed_time()/1000
        #new_pose = self.odometry()  //To be defined by students?

        
        global_velocities = robot_to_global_frame(robot_velocities, self.pose.theta)
        
        g_vel = Vel(global_velocities[0],global_velocities[1],global_velocities[2])
        

        if self.custom_method:
            x, y, th = self.custom_method(g_vel, dt)
        # Pendiente ocultar
        elif self.method == "Euler":
            x, y, th = euler(self.pose, g_vel, dt)
            
        elif self.method == "Bilineal":
             x, y, th = bilineal(self.pose,self.pose_prev, g_vel, self.vel_prev, dt)

        #Placeholder para otros métodos
        elif self.method == "R2K":
            print("R2K")

        else:
            raise ValueError(f"Método de estimación no soportado: {self.method}")
            
        self.pose_prev2 = self.pose_prev
        self.pose_prev = self.pose

        self.vel_prev = g_vel
        self.pose = Pose(x=x*scale,y=y*scale,theta=theta)

        return self.pose

