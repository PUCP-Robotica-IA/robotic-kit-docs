#===============================================================================
# Archivo     : sequence.py
# Módulo      : robot
# Propósito   : Ejecutar una secuencia de movimientos con tiempos definidos.
#-------------------------------------------------------------------------------
#Autores     :
#    - Fiorella Urbina (f.urbina@pucp.edu.pe)
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
# Curso       : 1MTR53 - Robótica e Inteligencia Artificial
# Institución : PUCP - Facultad de Ciencias e Ingeniería
# Fecha       : 2025-07-07
# Versión     : 1.2
#
#Dependencias:
#    - machine (Timer)
#    - ucollections (namedtuple)
#
#Historial de cambios:
#    - v1.0   (2025-06-29) Fiorella Urbina: Versión inicial con lógica de timers
#    - v1.1   (2025-07-02) Diego Quiroz: Encapsulamiento en clase Sequence
#    - v1.2   (2025-07-07) Fiorella Urbina: Cambio de nombre de elementos a "step"
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from ucollections import namedtuple
from machine import Timer

#===========================================================================
# Definición de estructura de datos para cada paso de la secuencia
# vx     : velocidad lineal en X (m/s)
# vy     : velocidad lineal en Y (m/s)
# w      : velocidad angular (rad/s)
# time   : duración del movimiento (segundos)
#===========================================================================
step = namedtuple("step",("vx","vy","w","time"))

class Sequence:
    def __init__(self, sequence_list, robot):
        '''
        Inicializa el gestor de secuencias.

        Parámetros:
          sequence_list: Lista de elementos tipo step (vx, vy, w, time)
          robot        : Objeto de tipo MobileRobot o derivado
        '''
        self.sequence_list = sequence_list
        self.robot = robot
        self.N_SEQ = len(self.sequence_list)
        self.seq_idx = 0
        self._timer = Timer()
        self.step_callback_fn = None
    #===========================================================================
    # Ejecuta el siguiente paso de la secuencia. Si aún quedan pasos, aplica
    # las velocidades al robot y programa el siguiente paso tras el tiempo dado.
    # Al finalizar toda la secuencia, el robot se detiene automáticamente.
    #===========================================================================
    def nextStep(self):
        '''
        Actualiza los setpoints de velocidad según la secuencia actual en el arreglo
        SEQUENCES. Luego establece un timer para el siguiente cambio de secuencia.
        '''
        if(self.seq_idx < self.N_SEQ):
            if(self.step_callback_fn):
                self.step_callback_fn()
            
            seq = self.sequence_list[self.seq_idx]
            print(f"[Sequence] Iniciando paso {self.seq_idx}: vx={seq.vx:.2f}, vy={seq.vy:.2f}, w={seq.w:.2f}, t={seq.time}s")

            # Actualiza setpoints de velocidades
            self.robot.move(seq.vx, seq.vy, seq.w)         
            self.seq_idx+=1
            
            # Timer para ejecutar siguiente cambio de secuencia pasados x ms
            self._timer.init(
                mode=Timer.ONE_SHOT,
                period=round(seq.time * 1000),
                callback=lambda t: self.nextStep()
            )
        else:
            # Si recorrió todas las secuencias, se detiene y no vuelve a establecer un timer
            self.robot.move(0 , 0 , 0)
            print("[Sequence] === FIN DE SECUENCIA ===")
        
    #===========================================================================
    # Inicia la ejecución de la secuencia desde el primer paso.
    # Esta función debe ser llamada una sola vez.
    #===========================================================================
    def execute(self):
        '''
        Lanza la ejecución de la secuencia desde el paso inicial.
        '''
        self.seq_idx = 0
        print("[Sequence] Ejecutando secuencia...")
        self._timer.init(
            period=0,
            mode=Timer.ONE_SHOT,
            callback=lambda t: self.nextStep()
        )
    
