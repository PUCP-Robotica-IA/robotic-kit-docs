#===============================================================================
#Archivo     : test_mqtt.py
#Módulo      : tests/
#Propósito   : Ejecuta una prueba de comunicación y teleperación mediante MQTT
#-------------------------------------------------------------------------------
#Autores     :
#    - Gruzver Phocco (gruzver.phocco@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-13
#Versión     : 1.0.1
#
#Dependencias:
#    - config.CONFIG
#    - robot.get_robot
#    - utils.communication (CommunicationManager)
#
#Historial de cambios:
#    - v1.0   (2025-07-10) Gruzver Phocco: Versión Inicial para gestion de sensores.
#    - v1.0.1 (2025-07-13) Diego Quiro: Cambios para usar Sensor y Communication Managers en robot
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from machine import Pin
# Diccionario de configuración que contiene parámetros del robot
from config import CONFIG
# Función que retorna una instancia del robot basado en el tipo
from robot import get_robot
# Clase para gestionar la comunicacion entre el robot y un servidor
from utils.communication import CommunicationManager
# Diccionario de configuracion de servidor
from config.student_config import COMMUNICATION_CFG

from utime import sleep
import _thread

#=========================================================
# Selección del tipo de robot a utilizar en el test.
# Debe de estar definido el config.py
#=========================================================

led = Pin("LED", Pin.OUT)


ROBOT_TYPE = 'mecanum'
robot = None
comm = CommunicationManager(COMMUNICATION_CFG.get('MQTT'))

cmd = b""
cmd_prev = b""

def sensorsThread():
    global robot, comm
    sensors = robot.sensors         # Usa SensorManager
    while True:
        theta = sensors.read_imu_theta()
        dist_left = sensors.read_ultrasonic_value('left')
        dist_center = sensors.read_ultrasonic_value('center')
        dist_right = sensors.read_ultrasonic_value('right')
        robot.publish_value(str(theta), "sensors/imu/theta")
        robot.publish_value(str(dist_left), "sensors/ultrasonic/left")
        robot.publish_value(str(dist_center), "sensors/ultrasonic/center")
        robot.publish_value(str(dist_right), "sensors/ultrasonic/right")
        sleep(0.1)

def teleop_thread():
    global robot, comm
    cmd_prev = None
    while True:
        msg = comm.subscribe_value("teleop/cmd")
        if msg and msg != cmd_prev:
            cmd_prev = msg
            robot.simple_teleop(msg)
        sleep(0.1)
        
def main():
    
    global robot, cmd, cmd_prev
    
    sleep(5)
    led.toggle()
    robot = get_robot(ROBOT_TYPE, CONFIG[ROBOT_TYPE])
    led.toggle()
    sleep(1)
    _thread.start_new_thread(sensorsThread, ())
    _thread.start_new_thread(teleop_thread, ())
    
    while True:
        sleep(1)
        #if cmd != cmd_prev:
        #    cmd_prev = cmd
        #    robot.handle_command(cmd)
        #    led.toggle()
            
        
if __name__ == "__main__":
    main()
