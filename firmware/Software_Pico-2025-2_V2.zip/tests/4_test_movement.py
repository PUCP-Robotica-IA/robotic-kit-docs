from config import CONFIG
from robot import get_robot
import time

ROBOT_TYPE = 'mecanum'
robot = get_robot(ROBOT_TYPE, CONFIG[ROBOT_TYPE])

while True:
    robot.move(vx=1, vy=0, omega=0)
    time.sleep(0.5)
    robot.stop()
    time.sleep(0.5)
    
    robot.move(vx=0, vy=1, omega=0)
    time.sleep(0.5)
    robot.stop()
    time.sleep(0.5)
    
    robot.move(vx=-1, vy=0, omega=0)
    time.sleep(0.5)
    robot.stop()
    time.sleep(0.5)
    
    robot.move(vx=0, vy=-1, omega=0)
    time.sleep(0.5)
    robot.stop()
    time.sleep(0.5)