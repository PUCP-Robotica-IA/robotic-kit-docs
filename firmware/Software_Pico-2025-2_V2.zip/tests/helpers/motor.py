#===============================================================================
#Archivo     : motor_test.py
#Módulo      : tests.helpers
#Propósito   : Contiene diversas funciones empleadas para probar el funcionamiento
#              de los motores empleados
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-02
#Versión     : 1.0
#
#Dependencias:
#    - utime (MicroPython timing)
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
import utime

#===============================================================================
# Esta función permite validar el correcto sentido de giro de un motor y
# verificar la correspondencia del signo de velocidad con el sentido del movimiento.
# Se ejecutan dos pruebas: avance y retroceso, registrando el promedio de
# velocidad y la cantidad de pulsos del encoder en cada caso.
# ESTO DEBE VALIDARSE ANTES DE USAR PID
#===============================================================================
def test_wheel_direction(robot, motor_id, test_speed=20, duration=2.0, interval=0.2):
    '''
    Ejecuta una prueba de diagnóstico sobre un motor específico del robot móvil.

    Parámetros:
      robot: Instancia del robot móvil (debe tener lista de motores)
      motor_id: Índice del motor a evaluar
      test_speed: Velocidad de prueba (PWM interno)
      duration: Duración de cada fase (avance y retroceso), en segundos
      interval: Intervalo de muestreo para imprimir velocidad, en segundos
    '''
    # Validación de índice de motor
    if not 0 <= motor_id < len(robot.motors):
        print(f"[ERROR] motor_id {motor_id} fuera de rango")
        return
    
    # Se asegura de usar el motor en lazo abierto para evitar
    # problemas con PID mal configurado
    test_motor = robot.motors[motor_id]
    test_motor.enable_close_loop_control(enabled=False)
    test_speed = abs(test_speed)
    
    #=========================================================
    # Función interna para ejecutar el test en un sentido.
    # Aplica velocidad, registra mediciones y detiene el motor.
    #=========================================================
    def run_test(direction):
        if direction==1:
            print(f"\n[TEST] Motor {motor_id} - Sentido de avance (+)")
        else:
            print(f"\n[TEST] Motor {motor_id} - Sentido de retroceso (-)")
        speeds = []
        count_start = test_motor.encoder.get_count() # Lectura inicial del encoder
        test_motor.set_speed(direction * test_speed) # Aplicar velocidad
        
        t_start = utime.ticks_ms()
        while utime.ticks_diff(utime.ticks_ms(), t_start) < duration * 1000:
            speed = test_motor.get_speed()
            speeds.append(speed)
            print(f"Velocidad: {speed:.2f} RPM")
            utime.sleep(interval)

        test_motor.set_speed(0)
        count_end = test_motor.encoder.get_count()
        delta = abs(count_end - count_start) # Permite validar el PPR del encoder
        return speeds, delta
    
    # Prueba hacia delante
    speeds_fwd, delta_fwd = run_test(1)
    # Pausa antes de invertir
    utime.sleep(1)
    # Prueba hacia atrás
    speeds_rev, delta_rev = run_test(-1)
    
    # Análisis de velocidades
    avg_fwd = sum(speeds_fwd) / len(speeds_fwd)
    avg_rev = sum(speeds_rev) / len(speeds_rev)

    print("\n--- RESULTADOS ---")
    print(f"Promedio adelante: {avg_fwd:.2f} RPM \t Pulsos encoder: {delta_fwd}")
    print(f"Promedio atrás:    {avg_rev:.2f} RPM \t Pulsos encoder: {delta_rev}")
    
    print("Sentido de rotación evaluado. Validar visualmente si el motor gira en el sentido correcto.")
    print("   → Si no, configurar 'inverted': True en la instancia del motor.")
    if avg_fwd < 0:
        print("Velocidad de avance es negativa, configurar 'encoder_inverted': True en la instancia del motor.")