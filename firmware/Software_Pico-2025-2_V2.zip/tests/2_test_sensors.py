#===============================================================================
#Archivo     : 2_test_sensors.py
#Módulo      : tests/
#Propósito   : Ejecuta una prueba de diagnóstico sobre los sensores de un robot
#              móvil, incluyendo IMU y sensores ultrasónicos, para verificar
#              su correcto funcionamiento y lectura de datos.
#-------------------------------------------------------------------------------
#Autores     :
#    - Lucía Sarmiento (lucia.sarmiento@pucp.edu.pe)
#    - Rodrigo Carbajal (rodrigo.carbajals@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-08-09
#Versión     : 1.0
#
#Dependencias:
#    - config.CONFIG
#    - robot.get_robot
#    - sensors.SensorManager
#    - robot.test_sensors
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================

# Diccionario de configuración que contiene parámetros del robot
from config import CONFIG
# Función que retorna una instancia del robot basado en el tipo
from robot import get_robot

#=========================================================
# Selección del tipo de robot a utilizar en el test.
# Debe de estar definido el config.py
#=========================================================
ROBOT_TYPE = 'mecanum'
# Inicializa la instancia del robot con los parámetros correspondientes
robot = get_robot(ROBOT_TYPE, CONFIG[ROBOT_TYPE])

# ================================================
# Ejecución de la prueba de sensores
# ================================================

# Llama al método test_sensors del robot para realizar:
# 1. Prueba de la IMU
# 2. Prueba de sensores ultrasónicos
# Cada prueba dura 'time' segundos (por defecto 5 segundos).
robot.test_sensors(time=10)
