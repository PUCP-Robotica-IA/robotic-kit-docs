#===============================================================================
#Archivo     : test_motor_01.py
#Módulo      : tests/
#Propósito   : Ejecuta una prueba de diagnóstico sobre el motor 1 de un robot
#              móvil para verificar el sentido de giro y lectura del encoder.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-02
#Versión     : 1.0
#
#Dependencias:
#    - tests.helpers.motor.test_wheel_direction
#    - config.CONFIG
#    - robot.get_robot
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================

# Función de diagnóstico para verificar sentido de giro y lectura del encoder
from tests.helpers.motor import test_wheel_direction
# Diccionario de configuración que contiene parámetros del robot
from config import CONFIG
# Función que retorna una instancia del robot basado en el tipo
from robot import get_robot

#=========================================================
# Selección del tipo de robot a utilizar en el test.
# Debe de estar definido el config.py
#=========================================================
ROBOT_TYPE = 'mecanum'
# Inicializa la instancia del robot con los parámetros correspondientes
robot = get_robot(ROBOT_TYPE, CONFIG[ROBOT_TYPE])

# Ejecuta la prueba en el motor con índice 1
# Realizar la prueba con cada motor y modificar la configuración
# en config.py según corresponda
test_wheel_direction(robot, motor_id=0)