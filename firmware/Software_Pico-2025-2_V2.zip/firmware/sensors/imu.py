#===============================================================================
#Archivo     : imu.py
#Módulo      : sensors
#Propósito   : Obtener el ángulo de un sensor inercial. Se utiliza
#              para estimar la posición angular y velocidad lineal del robot.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#    - Gruzver Phocco (gruzver.phocco@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-06-30
#Versión     : 1.0
#
#Dependencias:
#    - machine (I2C)
#
#Historial de cambios:
#    - v1.0 (2025-06-14) Gruzver Phocco: Encapsulamiento en clase inicial.
#                                      Lectura de datos.
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
import machine, time
import math 
from machine import Pin, I2C
from time import sleep, ticks_ms, ticks_diff
from libraries.lib_imu import MPU6050

class IMUSensor:
    """
    Clase para sensores IMU con salida digital conectados por I2C a líneas SDA/SCL.
    """
    def __init__(self, sensor_config=None):
        
        '''
        Inicializa un sensor IMU con asignación de pines I2C y calibración

        Parámetros:
        i2c_id        : Número de bus I²C (p. ej. 0 o 1)
        sda_pin       : Número del pin SDA
        scl_pin       : Número del pin SCL
        freq          : Frecuencia del bus I²C en Hz (por defecto 400000)
        settling_time : Tiempo de estabilización en segundos (por defecto 2)
        calib_time    : Tiempo de calibración en segundos (por defecto 3)
        '''

        # 1. Parámetros
        i2c_id        = sensor_config.get('i2c_id', 0)
        sda_pin       = sensor_config.get('sda')
        scl_pin       = sensor_config.get('scl')
        freq          = sensor_config.get('freq', 400000)
        settling_time = sensor_config.get('settling_time', 2)
        calib_time    = sensor_config.get('calib_time',    3)

        # 2. Inicializar I²C e IMU
        self.i2c = I2C(i2c_id, sda=Pin(sda_pin), scl=Pin(scl_pin), freq=freq)
        self.imu = MPU6050(self.i2c)

        # 3. Calibración de giroscopio
        print(f'Calibrando IMU con settling_time: {settling_time} y tiempo de calibración: {calib_time}')
        sleep(settling_time)
        self.offset_x, self.offset_y, self.offset_z = self._gyro_calibration(calib_time)

        # 4. Variables
        self.angle_z   = 0.0
        self._last_time = ticks_ms()

    def _get_raw_gyro(self):
        """Devuelve (gx, gy, gz) sin corregir."""
        return self.imu.gyro.x, self.imu.gyro.y, self.imu.gyro.z

    def _gyro_calibration(self, calibration_time):
        """Calcula offsets medios del giroscopio en calibration_time segundos."""
        print('--' * 25)
        
        sums = [0.0, 0.0, 0.0]
        count = 0
        end_t = time.time() + calibration_time
        while time.time() < end_t:
            gx, gy, gz = self._get_raw_gyro()
            sums[0] += gx
            sums[1] += gy
            sums[2] += gz
            count += 1
            if (count % 100) == 0:
                print(f'…{count} lecturas…')
        offsets = [s / count for s in sums]
        
        print(f'Calibración completa: {count} lecturas.')
        print('Offsets:', offsets)
        return offsets

    def read(self):
        """
        Lee sensores, corrige giroscopio e integra para ángulo Z.
        Devuelve un dict con:
          angle_z, ax, ay, az, gx, gy, gz, temperature
        """
        # leer y corregir giroscopio
        raw_gx, raw_gy, raw_gz = self._get_raw_gyro()
        gz = raw_gz - self.offset_z

        # tiempo transcurrido
        now = ticks_ms()
        dt = ticks_diff(now, self._last_time) / 1000.0
        self._last_time = now

        # acumular ángulo Z
        self.angle_z = (self.angle_z + gz * dt) % 360.0

        # lecturas restantes
        ax = self.imu.accel.x
        ay = self.imu.accel.y
        az = self.imu.accel.z
        gx = raw_gx - self.offset_x
        gy = raw_gy - self.offset_y
        tem = self.imu.temperature

        # redondear y devolver
        return {
            'angle_z': round(self.angle_z, 2),
            'ax': round(ax, 2), 'ay': round(ay, 2), 'az': round(az, 2),
            'gx': round(gx, 2), 'gy': round(gy, 2), 'gz': round(gz, 2),
            'temperature': round(tem, 2),
        }
    def read_theta(self, in_radian=False):
        '''
        Calcula el ángulo theta con la integral de la lectura en yaw

        Parámetros:
            in_radian : Boleano que define las unidades de retorno para theta

        Salida:
            theta     : Angulo theta en grados [°] o radianes [rad]
        '''
        # leer y corregir giroscopio
        raw_gx, raw_gy, raw_gz = self._get_raw_gyro()
        gz = raw_gz - self.offset_z

        # tiempo transcurrido
        now = ticks_ms()
        dt = ticks_diff(now, self._last_time) / 1000.0
        self._last_time = now

        # acumular ángulo Z
        self.angle_z = (self.angle_z + gz * dt) % 360.0

         # 4. Devolver en el formato deseado
        if in_radian:
            # Convertir grados a radianes
            yaw_rad = self.angle_z * math.pi / 180.0
            return round(yaw_rad, 4)
        else:
            # Devolver grados con dos decimales
            return round(self.angle_z, 2)
