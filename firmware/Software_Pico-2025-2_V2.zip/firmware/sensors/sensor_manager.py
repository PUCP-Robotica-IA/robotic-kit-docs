#===============================================================================
#Archivo     : sensor_manager.py
#Módulo      : sensor
#Propósito   : Clase que gestiona lectura de sensores para sistemas robóticos.
#-------------------------------------------------------------------------------
#Autores     :
#    - Gruzver Phocco (gruzver.phocco@pucp.edu.pe)
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-13
#Versión     : 1.0
#
#Dependencias:
#    - robot.base (MobileRobot)
#    - utils.jacobians (mecanum_jacobian)
#    - sensor.ultrasonic_array (UltrasonicArray)
#
#Historial de cambios:
#    - v1.0   (2025-07-13) Diego Quiroz: Versión Inicial para gestion de sensores.
#    - v1.1   (2025-07-13) Lucía Sarmiento y Rodrigo Carbajal: Versión que incluye la prueba de sensores en el kit.

#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from sensors.ultrasonic_array import UltrasonicArray
from sensors.imu import IMUSensor
import utime

class SensorManager:
    def __init__(self, sensor_config):
        '''
        Inicializa los sensores disponibles según el diccionario de configuración.

        Ejemplo de config:
          {
              "ultrasonic": {"front": 26, "left": 27, "right": 28},
              "imu": {"i2c_id": 0, "sda": 16, "scl": 17}
          }
        '''
        if sensor_config and "ultrasonic" in sensor_config:
            self.ultrasonic = UltrasonicArray(sensor_config["ultrasonic"])
        else:
            self.ultrasonic = None
            
        if sensor_config and "imu" in sensor_config:
            self.imu = IMUSensor(sensor_config["imu"])
        else:
            self.imu = None

    #=========================================================
    # Estas funciones corresponden al sensor imu
    #=========================================================
    def read_imu_theta(self, in_radian=False):
        if self.imu:
            return self.imu.read_theta(in_radian)
        return None
    
    def read_imu_values(self):
        if self.imu:
            return self.imu.read()
        return None
    
    #=========================================================
    # Estas funciones corresponden a los sensores ultrasónicos
    #=========================================================
    def read_ultrasonic_value(self, id_ultr, unit='mm'):
        '''
        Retorna la distancia leída por un sensor ultrasónico específico.

        Parámetros:
          sensor_id: Identificador lógico del sensor (ej. "front", "left")
          unit     : Unidad de medida ('mm' o 'cm')

        Salida:
          Distancia en la unidad especificada
        '''
        if self.ultrasonic:
            return self.ultrasonic.read(id_ultr, unit)
        return none
    
    def read_ultrasonic_all(self, unit='mm'):
        '''
        Retorna la lectura de todos los sensores ultrasónicos disponibles.

        Parámetros:
          unit: Unidad de medida ('mm' o 'cm')

        Salida:
          Diccionario con las distancias medidas por sensor.
          Ej: {"front": 20.4, "left": 18.0, "right": 22.3}
        '''
        if self.ultrasonic:
            return self.ultrasonic.read_all(unit)
        return None
    def test_sensors(self, time):
        """
        Realiza pruebas de lectura de los sensores IMU y ultrasónicos durante un tiempo determinado.

        Parámetros
        ----------
        time : Tiempo total (en segundos) que se dedicará a la prueba de cada tipo de sensor.

        Funcionamiento
        --------------
        1. **Prueba de IMU**:
            - Lee los valores de la IMU usando `self.sensors.read_imu_values()`.
            - Muestra los valores por consola cada 0.5 segundos durante el tiempo indicado.

        2. **Prueba de sensores ultrasónicos**:
            - Lee las distancias de todos los sensores ultrasónicos usando `self.sensors.read_ultrasonic_all()`.
            - Muestra los valores por consola cada 0.5 segundos durante el tiempo indicado.

        Salidas
        -------
        - No retorna ningún valor.
        - Imprime en consola las lecturas de cada sensor.

        Notas
        -----
        - El tiempo de espera entre lecturas está fijado en 0.5 segundos para permitir
        al alumno observar los cambios sin saturar la salida en consola.
        """
        start_time = utime.ticks_ms()
        print("--------------------Prueba IMU---------------------")
        while(utime.ticks_ms() - start_time < time*1e3):
            imu_values=self.read_imu_values()
            print("Lectura IMU: ",imu_values)
            utime.sleep(0.5)

        start_time = utime.ticks_ms()
        print("\n----------------Prueba Ultrasonidos--------------")
        while(utime.ticks_ms() - start_time < time*1e3):
            ultrasonic_values=self.read_ultrasonic_all()
            print("Lectura ultrasonidos: ",ultrasonic_values)
            utime.sleep(0.5)