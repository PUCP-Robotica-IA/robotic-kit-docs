import math

def robot_to_global_frame(robot_velocities, theta):
    '''
    Convierte velocidades del marco del robot al marco global.
    
    Parámetros:
        robot_velocities: Lista o tupla (vx_robot, vy_robot, omega)
        theta: Orientación del robot [rad]

    Retorno:
        Lista [vx_global, vy_global]
    '''
    vx, vy, omega = robot_velocities
    ct = math.cos(theta)
    st = math.sin(theta)

    return [ct * vx - st * vy,
            st * vx + ct * vy,
            omega]

def global_to_robot_frame(global_velocities, theta):
    '''
    Convierte velocidades del marco global al marco del robot.
    
    Parámetros:
        global_velocities: Lista o tupla (vx_global, vy_global, omega)
        theta: Orientación del robot [rad]

    Retorno:
        Lista [vx_robot, vy_robot]
    '''
    vx, vy, omega = global_velocities
    ct = math.cos(theta)
    st = math.sin(theta)

    return [ct * vx + st * vy,
           -st * vx + ct * vy,
            omega]