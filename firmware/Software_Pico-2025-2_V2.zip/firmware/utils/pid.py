#===============================================================================
#Archivo     : pid.py
#Módulo      : utils
#Propósito   : Clase que define un controlador PID
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-06-20
#Versión     : 0.1
#
#Dependencias:
#    - robot.motor_driver (MotorWithPID)
#
#Historial de cambios:
#    - v0.1   (2025-06-20) Diego Quiroz: Versión Inicial, control simple
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
class PID:
    def __init__(self, kp, ki, kd, output_limits=(-100, 100)):
        if kp is None: kp = 0
        if ki is None: ki = 0
        if kd is None: kd = 0
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
        self.pid_proportional=0
        self.pid_integral=0
        self.pid_derivative=0

        self.min_output, self.max_output = output_limits

    def compute(self, target, current):
        error = target - current
        self.integral += error*10/1000  # Asumiendo dt = 10 ms
        self.integral = max(min(self.integral, self.max_output), self.min_output)

        derivative = error - self.prev_error
        self.prev_error = error
        
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        output = max(min(output, self.max_output), self.min_output)

        return output
    
    def reset(self):
        return
    
    def restart(self):
        self.pid_proportional=0
        self.pid_integral=0
        self.pid_derivative=0
        self.integral=0
        self.prev_error=0
