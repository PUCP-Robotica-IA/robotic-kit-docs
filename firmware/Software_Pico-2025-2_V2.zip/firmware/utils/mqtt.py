#===============================================================================
#Archivo     : mqtt.py
#Módulo      : utils
#Propósito   : Comunicación mediante protocolo MQTT usando una red wifi y el broker libre hivemq
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#    - Gruzver Phocco (gruzver.phocco@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-08
#Versión     : 1.0
#
#Dependencias:
#    - libraries (lib_mqtt)
#
#Historial de cambios:
#    - v1.0 (2025-06-14) Gruzver Phocco: Encapsulamiento en clase inicial, conexión a red.
#    - v1.1 (2025-07-23) Gruzver Phocco: Mejora en el comportamiento de funciones MQTT.
#                                      
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================

import network
import time
import machine
from libraries.lib_mqtt import MQTTClient

class MQTT:
    """
    Clase para comunicación MQTT
    """
    def __init__(self, mqtt_config=None):
        """
        Inicializa la conexión MQTT con parámetros de red y broker.

        Parámetros:
            ssid         : SSID de la red Wi-Fi (por defecto "redpucp")
            password     : Contraseña de la red Wi-Fi (por defecto "C9AA28BA93")
            mqtt_server  : Dirección del broker MQTT (por defecto "broker.hivemq.com")
            client_id    : Identificador del cliente MQTT (por defecto None, se genera automáticamente)
            wifi_timeout : Tiempo de espera para conectar a la red Wi-Fi en segundos (por defecto 10)
        """
        cfg = mqtt_config or {}

        # 1. Parámetros
        self.ssid           = cfg.get('ssid', "redpucp")
        self.password       = cfg.get('password', "C9AA28BA93")
        self.mqtt_server    = cfg.get('mqtt_server', "broker.hivemq.com")
        self.wifi_timeout   = cfg.get('wifi_timeout', 20)
        self.client_id      = cfg.get('client_id') or self._generate_client_id()
        
        self.received_messages = {}
        self.message_handlers = {}
        self.subscribed_topics = set()
        
        # 2. Conexión Wi-Fi
        self._connect_wifi(self.ssid, self.password, self.wifi_timeout)

        # 3. Preparar y conectar MQTT
        self._setup_mqtt(self.client_id, self.mqtt_server)

    def _generate_client_id(self):
        raw = machine.unique_id()
        return b"pico_" + b''.join(b'%02x' % b for b in raw)

    def _connect_wifi(self, ssid, password, timeout):
        """Conecta a la red Wi-Fi y guarda la interfaz en self.wlan."""
        wlan = network.WLAN(network.STA_IF)
        if not wlan.active():
            wlan.active(True)
            time.sleep(0.5)
        
        if not wlan.isconnected():
            print(f"Conectando a {self.ssid}...", end="")
            wlan.connect(self.ssid, self.password)
            
            start = time.ticks_ms()
            while not wlan.isconnected():
                if time.ticks_diff(time.ticks_ms(), start) > self.wifi_timeout * 1000:
                    raise RuntimeError("Timeout WiFi")
                print(".", end="")
                time.sleep(1)
        print(f"\nConectado a red: {ssid} con IP: {wlan.ifconfig()[0]}")
        self.wlan = wlan


    def _setup_mqtt(self, client_id, server):
        """
        Crea el cliente MQTT y se conecta.
        """
        self.client = MQTTClient(self.client_id, self.mqtt_server)
        self.client.set_callback(self._global_callback)
        self.client.connect(clean_session=True)
        print(f"Conectado MQTT: {self.mqtt_server}")
        
    def _global_callback(self, topic, msg):
        topic_str = topic.decode()
        self.received_messages[topic_str] = (msg, time.ticks_ms())
        
        if topic_str in self.message_handlers:
            for handler in self.message_handlers[topic_str]:
                handler(msg)
    
    def add_callback(self, topic, handler):
        """Registra función handler(msg) para tópico"""
        if topic not in self.message_handlers:
            self.message_handlers[topic] = []
        self.message_handlers[topic].append(handler)

    def _safe_reconnect(self):
        try:
            self.client.disconnect()
        except:
            pass
        
        if not self.wlan.isconnected():
            try:
                self._connect_wifi()
            except Exception as e:
                print(f"Error reconectando WiFi: {e}")
        
        try:
            self.client.connect(clean_session=True)
            for topic in self.subscribed_topics:
                t = topic.encode() if isinstance(topic, str) else topic
                self.client.subscribe(t)
            print("Reconexión MQTT exitosa")
        except Exception as e:
            print(f"Error reconectando MQTT: {e}")
    
    def check_incoming(self, max_time=50):
        """Procesa mensajes entrantes con timeout"""
        start = time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(), start) < max_time:
            try:
                if self.client.check_msg() is None:
                    break
            except Exception as e:
                print(f"Error check_msg: {e}")
                break
    
    def get_last_msg(self, topic, max_age_ms=5000):
        """Obtiene mensaje reciente con caducidad"""
        if topic in self.received_messages:
            msg, timestamp = self.received_messages[topic]
            if time.ticks_diff(time.ticks_ms(), timestamp) < max_age_ms:
                return msg
        return None
    
    def subscribe_mqtt(self, topic):
        """Suscripción única a tópico"""
        if topic not in self.subscribed_topics:
            t = topic.encode() if isinstance(topic, str) else topic
            self.client.subscribe(t)
            self.subscribed_topics.add(topic)
    
    def publish_mqtt(self, topic, value, retain=False):
        """Publicación QoS 0 con reconexión automática"""
        t = topic if isinstance(topic, bytes) else topic.encode()
        v = value if isinstance(value, bytes) else str(value).encode()
        
        for attempt in range(2):
            try:
                self.client.publish(t, v, retain=retain)
                return True
            except Exception as e:
                if attempt == 0:
                    self._safe_reconnect()
        return False
