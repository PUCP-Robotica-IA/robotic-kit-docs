#===============================================================================
# Archivo     : student_config.py
# Módulo      : config
# Propósito   : Definir configuraciones opcionales para motores que los alumnos
#               pueden modificar sin acceder a la configuración completa del robot.
#               Permite establecer las propiedades 'inverted' y 'encoder_inverted'
#               para cada motor.
#-------------------------------------------------------------------------------
# Autores     :
#     - Diego Quiroz (dequiroz@pucp.edu.pe)
#
# Carrera     : Ingeniería Mecatrónica
# Curso       : 1MTR53 - Robótica e Inteligencia Artificial
# Institución : PUCP - Facultad de Ciencias e Ingeniería
#
# Fecha       : 2025-07-13
# Versión     : 0.2
#
# Dependencias:
#     - Este archivo es utilizado por el módulo 'robot' para aplicar las
#       sobreescrituras definidas por los estudiantes sobre la configuración
#       base del hardware.
#
# Historial de cambios:
#     - v0.1   (2025-07-08) Diego Quiroz: Versión Inicial, permite flags de inversión
#     - v0.2   (2025-07-13) Diego Quiroz: Agrega configuracion de comunicacion MQTT
#
# Licencia:
#     Este software se distribuye con fines académicos bajo Creative Commons
#     Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#     modificación y distribución dentro de contextos educativos y de investigación
#     no comercial, siempre citando a los autores originales.
#===============================================================================

# Lista de sobreescrituras opcionales por motor
# Solo se permiten las llaves: 'inverted' y 'encoder_inverted'
# Especificar con el indice el id del motor a configurar.
MOTOR_DIRECTION = {
    0: {"inverted": False, "encoder_inverted": True},             # Motor 0
    1: {"inverted": False, "encoder_inverted": True},             # Motor 1
    2: {"inverted": False, "encoder_inverted": True},             # Motor 2
    3: {"inverted": True, "encoder_inverted": True},              # Motor 3


}


COMMUNICATION_CFG = {
    "MQTT": {"ssid": "redpucp", "password": "C9AA28BA93", "mqtt_server": "broker.hivemq.com"},
    "TCP": {"ssid": "redpucp", "password": "C9AA28BA93", "host": "192.168.1.100", "port": 6112}
}