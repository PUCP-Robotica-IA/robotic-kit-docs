#===============================================================================
#Archivo     : mecanum_robot.py
#Módulo      : robot
#Propósito   : Clase que define un robot omnidirecional con 4 ruedas mecano.
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-07-13
#Versión     : 1.0.7
#
#Dependencias:
#    - robot.base (MobileRobot)
#    - utils.jacobians (mecanum_jacobian)
#    - sensors (SensorManager)
#
#Historial de cambios:
#    - v1.0   (2025-06-18) Diego Quiroz: Versión Inicial para control de robot
#    - v1.0.5 (2025-07-01) Diego Quiroz: Integración con sensores ultrasonido
#    - v1.0.6 (2025-07-08) Gruzver Phocco: Integración con sensor imu
#    - v1.0.7 (2025-07-13) Diego Quiroz: Integración con SensorModule
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from robot.base import MobileRobot
from utils.jacobians import mecanum_jacobian, mecanum_inverse_jacobian
from sensors import SensorManager
from utils.mqtt import MQTT

class MecanumRobot(MobileRobot):
    def __init__(self, config):
        '''
        Inicializa un robot móvil con ruedas mecanum. Hereda de MobileRobot
        y utiliza la configuración proporcionada.

        Parámetros:
          config: Diccionario con los parámetros del sistema. Debe incluir
                  un item con la clave "motors" que define los pines que
                  fisicos donde se conecta cada motor.
        '''
        super().__init__(config["motors"])
        
        # Configuración de sensores en la plataforma omnidireccional
        sensor_config = config.get('sensors')
        self.sensors = SensorManager(sensor_config)
        
    #=========================================================
    # Esta función calcula la velocidad de cada rueda mecanum
    # a partir de las velocidades del chasis (vx, vy, omega).
    # Utiliza la matriz jacobiana correspondiente al modelo mecanum.
    #=========================================================
    def _compute_wheel_speeds(self, vx, vy, omega):
        '''
        Calcula las velocidades individuales de las ruedas mecanum.

        Parámetros:
          vx: Velocidad lineal en eje X [m/s]
          vy: Velocidad lineal en eje Y [m/s]
          omega: Velocidad angular del chasis [rad/s]

        Salida:
          Lista con velocidades de las 4 ruedas [w1, w2, w3, w4]
        '''
        J = self._inverse_jacobian()
        # Multiplicación vector-matriz: [vx, vy, omega] x J^T
        # Realizada manualmente para mayor compatibilidad con MicroPython
        return [
            vx * J[0][0] + vy * J[0][1] + omega * J[0][2],
            vx * J[1][0] + vy * J[1][1] + omega * J[1][2],
            vx * J[2][0] + vy * J[2][1] + omega * J[2][2],
            vx * J[3][0] + vy * J[3][1] + omega * J[3][2],
        ]

    #=========================================================
    #=========================================================
    def direct_kinematics(self, motor_velocities):
        J = robot._jacobian()
        
        return [
            motor_velocities[0] * J[0][0] + motor_velocities[1] * J[0][1] + motor_velocities[2] * J[0][2] + motor_velocities[3] * J[0][3],
            motor_velocities[0] * J[1][0] + motor_velocities[1] * J[1][1] + motor_velocities[2] * J[1][2] + motor_velocities[3] * J[1][3],
            motor_velocities[0] * J[2][0] + motor_velocities[1] * J[2][1] + motor_velocities[2] * J[2][2] + motor_velocities[3] * J[2][3],
        ]
    
    #=========================================================
    # Esta función retorna la matriz jacobiana por defecto para
    # un robot móvil con 4 ruedas mecanum. Este jacobiano describe
    # la relación entre las velocidades del chasis y de las ruedas.
    #=========================================================
    def default_jacobian(self):
        '''
        Retorna la matriz jacobiana para un robot con 4 ruedas mecanum.

        Salida:
          Matriz 4x3 que relaciona velocidades del chasis con ruedas.
        '''
        return mecanum_jacobian()
    
    def default_inverse_jacobian()
        return mecanum_inverse_jacobian()
    #=========================================================
    # Esta función debe ser implementada para actualizar la odometría
    # del robot mecanum. Puede combinar datos de encoders y sensores
    # inerciales para estimar la posición y orientación.
    #=========================================================
    def update_odometry(self, interval = 10, scale = 1, encoders=True, imu=False):
        '''
        Actualiza la posición estimada del robot en el espacio
        a partir de datos de sensores. (Aún no implementado)
        '''
        # Por ahora solo encoders, pendiente que sea compatible con lib imu.py
        #if encoders:
        #    self.pose = self._custom_estimation_fn(self.pose, self.pose_prev, 
        #                                self._compute_wheel_speeds(), interval / 1000.0)
        #    self.pose_prev = self.pose
        motor_velocities = self.get_motors_speed(units="rad_s") # rad/s
        robot_velocities = self.direct_kinematics(motor_velocities)
        self.pose = self.pose_estimator(self.sensors.imu.read_theta(True), robot_velocities, scale)
    
    #=========================================================
    # Estas funciones corresponden al control de motores
    #=========================================================
    # DQ: No se si esto es necesario. No veo mucha ventaje de usar
    # robot.move_motor(motor_id = 1, speed = 25)
    # vs
    # robot.motors[1].set_speed(25)
    # El min/max debería ser parte del motor para limitar su velocidad a un rango seguro, no del motor. 
    # Hasta donde he visto, tampoco se están usando.  Por ahora las comento
    #def move_motor(self, motor_id, speed=25):
    #    """
    #    Mueve un motor individual, limitando la velocidad entre -50 y 50.
    #    """
    #    self.motors[motor_id].set_speed(max(min(speed,50),-50))
    #    
    #def read_motor_velocity(self, motor_id):
    #    return self.motor[motor_id].get_speed()
    
    def simple_teleop(self, cmd, speed: float = 20.0, omega: float = 1.0):
        """
        Recibe un comando (bytes) y ajusta los cuatro motores.
        """
        if isinstance(cmd, bytes):
            cmd = cmd.decode('utf-8')
        cmd = cmd.strip().lower()
        
        wheel_map = {
        # CAMBIO POR DQ, por provar y validar. Una vez confirmado se puede borrar el código antiguo (comentado)
        #    'w': [ 1,  -1,  1, -1],  # Adelante
        #    's': [-1, 1, -1,  1],  # Atrás
        #    'a': [-1,  -1,  1,  1],  # Strafe Izquierda
        #    'd': [ 1, 1, -1, -1],  # Strafe Derecha
        #    'q': [-1,  -1, -1,  -1],  # Giro Izquierda (rotación antihoraria)
        #    'e': [ 1, 1,  1, 1],  # Giro Derecha (rotación horaria)
        #    'x':  [ 0,  0,  0,  0],  # Stop
            'w': ( speed,  0.0,   0.0),  # Adelante
            's': (-speed,  0.0,   0.0),  # Atrás
            'a': ( 0.0,   -speed, 0.0),  # Strafe Izquierda
            'd': ( 0.0,   speed, 0.0),  # Strafe Derecha
            'q': ( 0.0,    0.0,  -omega),  # Giro Izquierda (rotación antihoraria)
            'e': ( 0.0,    0.0,  omega),  # Giro Derecha (rotación horaria)
            'x': ( 0.0,    0.0,   0.0),  # Stop
        }

        if cmd not in wheel_map:
            print(f"[WARN] Comando desconocido: {cmd}")
            return
        
        vx, vy, w = wheel_map[cmd]
        print(f"[Teleop] Movimiento → vx: {vx}, vy: {vy}, w: {w}")
        self.move(vx, vy, w)

    #def stop_motors(self):
    #    for motor in self.motors:
    #        motor.set_speed(0)

    def test_sensors(self,time=5):
        #Time indica el tiempo de la medición de sensores
        self.sensors.test_sensors(time)
