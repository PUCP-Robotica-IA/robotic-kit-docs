from .mecanum_robot import MecanumRobot
#from .differential_robot import DifferentialRobot
#from .ackerman_robot import AckermanRobot
from config import merge_motor_directions

def get_robot(robot_type, config):
    config = merge_motor_directions(config)

    if robot_type == "mecanum":
        return MecanumRobot(config)
    elif robot_type == "test":
        return MecanumRobot(config)
    #elif robot_type == "differential":
    #    return DifferentialRobot(config)
    #elif robot_type == "ackerman":
    #    return AckermanRobot(config)
    else:
        raise ValueError("Unknown robot type")
