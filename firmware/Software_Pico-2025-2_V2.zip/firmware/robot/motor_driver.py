#===============================================================================
#Archivo     : motor_driver.py
#Módulo      : robot
#Propósito   : Clase que define el uso de un puente H para control de motores
#-------------------------------------------------------------------------------
#Autores     :
#    - Diego Quiroz (dequiroz@pucp.edu.pe)
#    - Fiorella Urbina (f.urbina@pucp.edu.pe)
#
#Carrera     : Ingeniería Mecatrónica
#Curso       : 1MTR53 - Robótica e Inteligencia Artificial
#Institución : PUCP - Facultad de Ciencias e Ingeniería
#
#Fecha       : 2025-06-24
#Versión     : 1.1
#
#Dependencias:
#    - machine (PIN, PWM)
#    - sensors.pioencoder (Encoder)
#    - utils.pid (PID)
#
#Historial de cambios:
#    - v1.0   (2025-06-18) Diego Quiroz: Versión Inicial para mover motores
#    - v1.0.1 (2025-06-20) Diego Quiroz: Se agregó funcionalidad PID (sin validar)
#    - v1.0.2 (2025-06-20) Fiorella Urbina: Corrección de error en función STOP
#    - v1.1   (2025-06-24) Diego Quiroz: Validación de PID. Función de cambio de giro de motor y encoder.
#    - v1.1.1 (2025-06-26) Fiorella Urbina: Corrección de mezcla de unidades. Ahora: default RPM y opción rad/s
#
#Licencia:
#    Este software se distribuye con fines académicos bajo Creative Commons
#    Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Se permite su uso,
#    modificación y distribución dentro de contextos educativos y de investigación
#    no comercial, siempre citando a los autores originales.
#===============================================================================
from machine import Pin, PWM
from sensors.test_encoder import Encoder
#from utils.pid_v2 import PID
from utils.pid import PID
import math

class MotorWithPID:
    _motor_id = 0
    def __init__(self, pwm_pin, dir_pin, encoder_a, encoder_b, freq=1000, inverted=False, encoder_inverted=False):
        self.instance_id = MotorWithPID._motor_id
        MotorWithPID._motor_id += 1
        
        # Conexiones de Hardware
        self.dir_pin = Pin(dir_pin, Pin.OUT)
        self.pwm = PWM(Pin(pwm_pin))
        self.pwm.freq(freq)
        self.encoder = Encoder(encoder_a, encoder_inverted)
        
        # Configuracion de control
        self.inverted = inverted
        self.use_pid = False
        self.pid = None
        self.target_speed = 0
        self.current_pwm = 0
        self.current_speed = 0
                
    def get_speed(self, units = "rpm"):
        '''
        Parámetros:
            units: "rpm" para revoluciones por minuto, "rad_s" para radianes por segundo
        Salida: Velocidad del motor en RPM
        '''
        factor = 1
        if units == "rad_s":
            factor =  3.1416 / 30
        elif units != "rpm":
            raise ValueError("Unidad no soportada. Use 'rpm' o 'rad_s'")
        
        if self.use_pid:
            return self.current_speed*factor
        
        return self.encoder.get_speed()*factor
    
    def get_speed_rad_s(self):
        
        return self.get_speed()*math.pi/30 
    
    def get_encoder_position(self):
        return self.encoder.get_count()
    
    def get_state(self):
        state = {
            'motor_id': self.instance_id,
            'current_speed': self.get_speed(),
            'current_position': self.get_encoder_position(),
            'target_speed': self.target_speed,
            'current_pwm': self.current_pwm
            }
        if self.pid is not None:
            state['PID'] = f'{self.pid.kp} {self.pid.ki} {self.pid.kd}'
        return state
            
    def set_speed(self, speed, units="rpm"):
        '''
        Parámetros:
            speed: Velocidad objetivo en rpm o rad/s
            units: "rpm" para revoluciones por minuto, "rad_s" para radianes por segundo
        '''
        if units == 'rad_s':
            speed = speed * 30 / 3.1415 # rad/s a rpm
        elif units != 'rpm':
            raise ValueError("Unidad no soportada. Use 'rpm' o 'rad_s'")
        
        if self.use_pid:
            self.set_target_speed(speed)
        else:
            percent = speed * 100 / (50.0*30/3.1415)  # Suponiendo 50 rps = 100% PWM
            self.set_pwm(percent)
    
    def set_pwm(self, duty_cycle):
        duty_cycle = max(min(duty_cycle, 100), -100)
        
        pwm_value = int(abs(duty_cycle) * 655.35)
        direction = duty_cycle >= 0
        self.encoder.set_direction(direction)
        if self.inverted:
            direction = not direction
        #Enviar señales a motor
        self.dir_pin.value(direction)
        
        self.pwm.duty_u16(pwm_value)
        self.current_pwm = pwm_value
        
    def set_target_speed(self, speed, units="rpm"):
        '''
        Parámetros:
            speed_rps: Velocidad objetivo en rpm o rad/s
            units: "rpm" para revoluciones por minuto, "rad_s" para radianes por segundo
        '''
        if units == 'rad_s':
            speed = speed * 30 / 3.1416
        elif units != 'rpm':
            raise ValueError("Unidad no soportada. Use 'rpm' o 'rad_s'")
        
        self.target_speed = speed
     
    def update(self):
        if not self.use_pid:
            print(f'motor {self.instance_id} esta en lazo abierto.')
            return
        if self.pid is None:
            print(f'motor {self.instance_id} PID no ha sido configurado.')
            return
        self.current_speed = self.encoder.get_speed()
        control = self.pid.compute(self.target_speed, self.current_speed)
        #self.pid.setpoint = self.target_speed
        #control = self.pid(self.current_speed)
        self.set_pwm(control)
        
    def stop(self):
        self.pwm.duty_u16(0)
        self.pid.restart()
        self.target_speed=0
        
    def tune_pid(self, kp=None, ki=None, kd=None):
        if self.pid is None:
            self.pid = PID(kp=0.0, ki=0.0, kd=0.0)
        if kp is not None: self.pid.kp = kp
        if ki is not None: self.pid.ki = ki
        if kd is not None: self.pid.kd = kd
        
    def enable_close_loop_control(self, enabled=False):
        self.use_pid = enabled